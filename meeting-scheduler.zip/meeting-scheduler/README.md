# meeting-scheduler
A webapp made using Django Framework to schedule meetings, appoinments etc.

**This app is in development**
