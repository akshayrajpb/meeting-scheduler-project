from django.apps import AppConfig


class MeetingsConfig(AppConfig):
    name = 'meetings'
